<?php
error_reporting(0);
$botToken = ''; // توکن ربات
$dbUserName = ''; // یوزرنیم دیتابیس
$dbPassword = ''; // پسورد دیتابیس
$dbName = ''; // نام دیتابیس
$botUrl = ''; // ادرس هاست و پوشه سورس
$admin = ; // آیدی عددی ادمین اصلی
?>
